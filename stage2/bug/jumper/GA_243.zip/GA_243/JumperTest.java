import static org.junit.Assert.*;

import org.junit.Test;
import info.gridworld.actor.ActorWorld;
import info.gridworld.actor.Bug;
import info.gridworld.actor.Flower;
import info.gridworld.actor.Rock;
import info.gridworld.grid.Location;
import info.gridworld.actor.*;

public class JumperTest {

	@Test
	public void testRock() {
		//init
		ActorWorld world = new ActorWorld();
		Jumper jumper1 = new Jumper();
		Jumper jumper2 = new Jumper();
		Rock rock1 = new Rock();
		Rock rock2 = new Rock();
		//adding the actor
		world.add(new Location(4,1), jumper1);
		world.add(new Location(3,1), rock1);
		world.add(new Location(4,5), jumper2);
		world.add(new Location(2,5), rock2);
		world.show();
		jumper1.act();
		assertEquals(new Location(2,1),jumper1.getLocation());
		assertEquals(Location.NORTH, jumper1.getDirection());
		assertNotNull(rock1.getGrid());
		jumper2.act();
		jumper2.act();
		assertEquals(new Location(2,7),jumper2.getLocation());
		assertEquals(Location.NORTHEAST,jumper2.getDirection());
		assertNotNull(rock2.getGrid());
		
	}
	@Test
	public void testFlower() {
		ActorWorld world = new ActorWorld();
		Flower flower1 = new Flower();
		Flower flower2 = new Flower();
		Jumper jumper1 = new Jumper();
		Jumper jumper2 = new Jumper();
		world.add(new Location(4,1), jumper1);
		world.add(new Location(3,1), flower1);
		world.add(new Location(4,5), jumper2);
		world.add(new Location(2,5), flower2);
		world.show();
		jumper1.act();
		assertEquals(new Location(2,1),jumper1.getLocation());
		assertEquals(Location.NORTH, jumper1.getDirection());
		assertNotNull(flower1.getGrid());
		jumper2.act();
		assertEquals(new Location(2,5),jumper2.getLocation());
		assertEquals(Location.NORTH,jumper2.getDirection());
		assertNull(flower2.getGrid());
	}
	@Test
	public void testBug() {
		ActorWorld world = new ActorWorld();
		Bug bug1 = new Bug();
		Bug bug2 = new Bug();
		Jumper jumper1 = new Jumper();
		Jumper jumper2 = new Jumper();
		world.add(new Location(4,1), jumper1);
		world.add(new Location(3,1), bug1);
		world.add(new Location(4,5), jumper2);
		world.add(new Location(2,5), bug2);
		world.show();
		jumper1.act();
		assertEquals(new Location(4,1),jumper1.getLocation());
		assertEquals(Location.NORTHEAST, jumper1.getDirection());
		assertNotNull(bug1.getGrid());
		jumper2.act();
		assertEquals(new Location(2,5),jumper2.getLocation());
		assertEquals(Location.NORTH,jumper2.getDirection());
		assertNull(bug2.getGrid());
	}
	@Test
	public void testActor() {
		ActorWorld world = new ActorWorld();
		Actor actor1 = new Actor();
		Actor actor2 = new Actor();
		Jumper jumper1 = new Jumper();
		Jumper jumper2 = new Jumper();
		world.add(new Location(4,1), jumper1);
		world.add(new Location(3,1), actor1);
		world.add(new Location(4,5), jumper2);
		world.add(new Location(2,5), actor2);
		world.show();
		jumper1.act();
		assertEquals(new Location(4,1), jumper1.getLocation());
		assertEquals(new Location(3,1), actor1.getLocation());
		assertEquals(Location.NORTHEAST, jumper1.getDirection());
		assertEquals(Location.NORTH, actor1.getDirection());
		assertNotNull(actor1.getGrid());
		jumper2.act();
		assertEquals(new Location(2,5), jumper2.getLocation());
		assertEquals(new Location(1,5), actor2.getLocation());
		assertEquals(Location.NORTH, jumper2.getDirection());
		assertEquals(Location.NORTH, actor2.getDirection());
		assertNotNull(actor2.getGrid());
	}
	@Test
	public void testJumper() {
		ActorWorld world = new ActorWorld();
		Jumper jumper1 = new Jumper();
		Jumper jumper2 = new Jumper();
		Jumper jumper3 = new Jumper();
		Jumper jumper4 = new Jumper();
		world.add(new Location(4,1), jumper1);
		world.add(new Location(3,1), jumper2);
		world.add(new Location(4,5), jumper3);
		world.add(new Location(2,5), jumper4);
		jumper2.setDirection(Location.SOUTH);
		jumper4.setDirection(Location.SOUTH);
		jumper1.act();
		jumper2.act();
		jumper3.act();
		jumper4.act();
		assertEquals(new Location(4,1),jumper1.getLocation());
		assertEquals(Location.NORTHEAST, jumper1.getDirection());
		assertEquals(new Location(3,1),jumper2.getLocation());
		assertEquals(Location.SOUTHWEST, jumper2.getDirection());
		assertEquals(new Location(4,5), jumper3.getLocation());
		assertEquals(Location.NORTHEAST, jumper3.getDirection());
		assertEquals(new Location(2,5), jumper4.getLocation());
		assertEquals(Location.SOUTHWEST, jumper4.getDirection());
	}
	@Test
	public void testOneStepOutOfGrid() {
		ActorWorld world = new ActorWorld();
		Jumper jumper1 = new Jumper();
		Jumper jumper2 = new Jumper();
		Jumper jumper3 = new Jumper();
		world.add(new Location(4,9), jumper1);
		world.add(new Location(5,9), jumper2);
		world.add(new Location(6,9), jumper3);
		jumper1.setDirection(Location.NORTHEAST);
		jumper2.setDirection(Location.EAST);
		jumper3.setDirection(Location.SOUTHEAST);
		jumper1.act();
		jumper2.act();
		jumper3.act();
		assertEquals(Location.SOUTHEAST, jumper1.getDirection());
		assertEquals(Location.SOUTH, jumper2.getDirection());
		assertEquals(Location.SOUTHWEST, jumper3.getDirection());
	}
	@Test
	public void testTwoStepOutOfGrid() {
		ActorWorld world = new ActorWorld();
		Jumper jumper1 = new Jumper();
		Jumper jumper2 = new Jumper();
		Jumper jumper3 = new Jumper();
		world.add(new Location(4,8), jumper1);
		world.add(new Location(5,8), jumper2);
		world.add(new Location(6,8), jumper3);
		jumper1.setDirection(Location.NORTHEAST);
		jumper2.setDirection(Location.EAST);
		jumper3.setDirection(Location.SOUTHEAST);
		jumper1.act();
		jumper2.act();
		jumper3.act();
		assertEquals(Location.SOUTHEAST, jumper1.getDirection());
		assertEquals(Location.SOUTH, jumper2.getDirection());
		assertEquals(Location.SOUTHWEST, jumper3.getDirection());
	}
	
}
